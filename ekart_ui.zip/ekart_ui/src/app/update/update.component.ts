import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { Product } from '../product';
import { UserService } from '../user.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  form: FormGroup;
  submitted:boolean=false;
  product:Product = new Product()
 productId : number;
 userId: number;
  constructor(private formBuilder: FormBuilder, private router:Router,private route:ActivatedRoute, private userservice:UserService, private home:HomeComponent) { }

  ngOnInit(): void {
  
    this.productId  = this.route.snapshot.params['productId'];
    this.userId  = this.route.snapshot.params['userId'];
    this.form = this.formBuilder.group({
      productName: ['', Validators.required],
      productType: [, Validators.required],
      price:['',[Validators.required,Validators.pattern('^[1-9][0-9]*$')]]
  });
  }

  onSubmit() {
    this.submitted = true;
    console.log(this.product);
  
    this.product.productId=this.productId;
    console.log(this.product);
    this.userservice.updateProduct(this.product).subscribe(data => console.log(data),err => console.log(err));
    this.home.ngOnInit();
    setTimeout(() => {
      this.router.navigate(['home', this.userId]);
    }, 500);
}
back(){
  var userId = this.route.snapshot.params.userId;
  this.router.navigate(['home', userId]);

}
logout(){
  localStorage.removeItem('userId');
  this.router.navigate(['/login'])
}
get f() { return this.form.controls; }

}
