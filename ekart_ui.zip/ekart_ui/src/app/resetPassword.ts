
export class ResetPassword{
    email: String;
    password: String;
    question: String;
    answer: String;
}