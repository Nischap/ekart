import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './product';
import { ResetPassword } from './resetPassword';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public currUser=new User()
private apiUrl = 'http://localhost:8888';
  constructor(private http: HttpClient) { }

  public registerUser(user: User): Observable<any>{
    return this.http.post(`${this.apiUrl}/registerUser`, user, {responseType: 'text'});
  }

  public getAuthenticate(email: String, password: String): Observable<any>{
    return this.http.get(`${this.apiUrl}/user/getAuthenticate/${email}/${password}`,{responseType: 'text'}); 
  }

  public getUer(userId: String): Observable<User>{
    return this.http.get<User>(`${this.apiUrl}/user/getUser/${userId}`);
  }

  public addProduct(userId: number, product: Product): Observable<any>{
    return this.http.post(`${this.apiUrl}/user/addProduct/${userId}`, product, {responseType: 'text'}); 
  }

  public updateProduct(product: Product): Observable<any>{
    return this.http.put(`${this.apiUrl}/user/updateProduct`, product, {responseType: 'text'}); 
  }

  public deleteProduct(userId: number,productId: number): Observable<any>{
    return this.http.delete(`${this.apiUrl}/user/deleteProduct/${userId}/${productId}`); 
  }

  public resetPassword(resetPassword: ResetPassword): Observable<any>{
    return this.http.put(`${this.apiUrl}/user/resetPassword`, resetPassword, {responseType: 'text'}); 
  }


  }

