import { Product } from "./product";

export class User{
    userId: number;
    email: String;
    password: String;
    firstName: String;
    lastName: String;
    question: String;
    answer: String;
    products: Product[];
}