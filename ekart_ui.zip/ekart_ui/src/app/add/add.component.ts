import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router ,ActivatedRoute} from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { Product } from '../product';
import { UserService } from '../user.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  form: FormGroup;
  submitted:boolean=false;
  product:Product = new Product()
  constructor(
    private formBuilder: FormBuilder, private router:Router, private userservice:UserService, private route:ActivatedRoute
    , private homeComponent: HomeComponent
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      productName: ['', Validators.required],
      productType: ['', Validators.required],
      price:['',[Validators.required,Validators.pattern('^[1-9][0-9]*$')]]
  });
  
  
  }
  
  onSubmit() {

    this.submitted = true;
    console.log(this.product);
    var userId = this.route.snapshot.params.userId;
    console.log(this.product);
    this.userservice.addProduct(userId,this.product).subscribe(data => console.log(data),err => console.log(err));
    console.log("Added");      
    this.homeComponent.ngOnInit();
    setTimeout(() => {
      this.router.navigate(['home', userId]);
    }, 500);
}

back(){
  var userId = this.route.snapshot.params.userId;
  this.router.navigate(['home', userId]);

}
logout(){
  localStorage.removeItem('userId');
  this.router.navigate(['/login'])
}
get f() { return this.form.controls; }
}
