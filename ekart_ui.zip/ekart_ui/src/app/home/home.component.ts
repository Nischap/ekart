import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { User } from '../user';
import { UserService } from '../user.service';
import { Product } from '../product';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {
  private productId: number;
 private userId:string ;
public user:User=new User();
public totalRecords:any;
public page:number=1;
public userName:String;
public isUser:boolean=true;

  constructor(
    private router:Router,
    private route:ActivatedRoute,
    private userService:UserService,
  ) { }

  ngOnInit(): void {
    this.userId = this.route.snapshot.params.userId;
    console.log("UserId"+this.userId);
     this.userService.getUer(this.userId)
         .subscribe(
                     data => {
                       console.log(data);
                         this.user = data;
                         this.totalRecords=this.user.products.length;
                         if(this.totalRecords==0){
                          this.isUser=false;
                        }
                     },
                     error => {
                         console.log(console.error());
                     });
      this.userName=this.user.firstName;
  }

 
  
  delete(i){
    var product:Product=new Product()
    var userId = this.user.userId
    product=this.user.products[i]
    this.userService.deleteProduct(userId, product.productId).subscribe(
      data => {
        console.log(data);
          this.user = data;
      },
      error => { err =>
          console.log(err);
      });
      setTimeout(() => {
        this.ngOnInit();
      }, 300);
      this.page=Math.floor(this.totalRecords/8);
      
      this.router.navigate(['home', userId]);

    
  }

  add(){
    this.router.navigate(['add',this.userId]);
  }
  logout(){
    localStorage.removeItem('userId');
    this.router.navigate(['/login'])
  }

  update(i){
    this.productId= this.user.products[i].productId;
    this.router.navigate(['update', this.userId, this.productId])
  
  }
}


