import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../user';
import { UserService } from '../user.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
    user: User = new User();
    form: FormGroup;
    submitted = false;
    show:boolean=false;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private userService: UserService
    ) { }

    ngOnInit() {
        this.form = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            emailid: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]],
            question: ['', Validators.required],
            answer: ['', Validators.required]
        });
    }

  
    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;
        console.log(this.user);
        this.userService.registerUser(this.user).subscribe(data => {
            console.log(data);
            this.user = new User();
            this.router.navigate(['login']);
            alert(data+". Please Login");
        }, 
        error => console.log(error));

        if (this.form.invalid) {
          console.log(this.findInvalidControls)
            return;
        }
    }
    findInvalidControls() {
        const invalid = [];
        const controls = this.form.controls;
        for (const name in controls) {
            if (controls[name].invalid) {
                invalid.push(name);
            }
        }
        return invalid;
    }
    toggle(){
        this.show=!this.show;
    }

}