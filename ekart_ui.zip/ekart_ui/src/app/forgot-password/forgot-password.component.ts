import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ResetPassword } from '../resetPassword';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  reset: ResetPassword = new ResetPassword();
    form: FormGroup;
    submitted = false;
    email: String;
    password: String;
    question: String;
    answer: String;
    show:boolean=false;

    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private userService: UserService
    ) { }

    ngOnInit() {
        this.form = this.formBuilder.group({
            username: ['', [Validators.required, Validators.email]],
            password: ['', Validators.required],
            question: ['', Validators.required],
            answer: ['', Validators.required]
        });

        // get return url from route parameters or default to '/'
    }

    // convenience getter for easy access to form fields

    onSubmit() {
        console.log(this.reset);

        this.submitted = true;
        console.log(this.question);
      this.userService.resetPassword(this.reset)
      .subscribe(
                  data => {
                      console.log(data);
                      if(data === 'Incorrect Details'){
                          alert(data+". Please try again!");

                  }
                  else{
                    alert(data+". Please Login.");
                    this.router.navigate(['login']);
                  }
                  },
                  error => {
                      console.log(console.error());
                  });
  

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }
      }
      toggle(){
        this.show=!this.show;
    }
}
