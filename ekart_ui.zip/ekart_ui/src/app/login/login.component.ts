import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { User } from '../user';
  
// import { AccountService, AlertService } from '@app/_services';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
  export class LoginComponent implements OnInit {
    user: User = new User();
      form: FormGroup;
      submitted = false;
      returnUrl: string;
      email: String;
      password: String;
      userId: string;
        show:boolean=false;
      constructor(
          private formBuilder: FormBuilder,
          private router: Router,
          private userService: UserService
      ) { }
  
      ngOnInit() {
          this.form = this.formBuilder.group({
              username: ['', [Validators.required, Validators.email]],
              password: ['', Validators.required]
          });
  
          // get return url from route parameters or default to '/'
      }
  
      // convenience getter for easy access to form fields
      get f() { return this.form.controls; }
  
      onSubmit() {
          this.submitted = true;
        this.userService.getAuthenticate(this.email, this.password)
        .subscribe(
                    data => {
                        this.userId = data;
                        console.log(data);
                        if(this.userId === 'Incorrect Username Or Password'){
                            alert(data+". Please try again!");

                    }
                    else{
                        localStorage.setItem('userId',this.userId);
                        this.router.navigate(['home', this.userId]);
                    }
                    },
                    error => {
                        console.log(console.error());
                    });
    
  
          // stop here if form is invalid
          if (this.form.invalid) {
              return;
          }
        }
    toggle(){
        this.show=!this.show;
    }
  }
