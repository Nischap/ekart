export class Product{
    productId: number;
    productName: String;
  productType: String;
    price: String;
}