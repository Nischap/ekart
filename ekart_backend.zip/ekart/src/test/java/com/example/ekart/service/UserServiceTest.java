package com.example.ekart.service;

import static com.example.ekart.util.Constants.ASSIGN_PRODUCT_RESPONSE;
import static com.example.ekart.util.Constants.AUTHENTICATION_ERROR_RESPONSE;
import static com.example.ekart.util.Constants.DELETED_PRODUCT_RESPONSE;
import static com.example.ekart.util.Constants.EMAIL_ID;
import static com.example.ekart.util.Constants.FIRST_NAME;
import static com.example.ekart.util.Constants.LAST_NAME;
import static com.example.ekart.util.Constants.PASSWORD;
import static com.example.ekart.util.Constants.PRICE;
import static com.example.ekart.util.Constants.PRODUCT_ID;
import static com.example.ekart.util.Constants.PRODUCT_NAME;
import static com.example.ekart.util.Constants.PRODUCT_NOT_FOUND_MESSAGE;
import static com.example.ekart.util.Constants.PRODUCT_TYPE;
import static com.example.ekart.util.Constants.REGISTER_USER_RESPONSE;
import static com.example.ekart.util.Constants.UPDATED_PRODUCT_RESPONSE;
import static com.example.ekart.util.Constants.USER_ID;
import static com.example.ekart.util.Constants.USER_NOT_FOUND_MESSAGE;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.ekart.entity.Product;
import com.example.ekart.entity.User;
import com.example.ekart.model.ProductDto;
import com.example.ekart.model.UserDto;
import com.example.ekart.repository.ProductRepository;
import com.example.ekart.repository.UserRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

  @Mock
  private UserRepository userRepository;

  @Mock
  private ProductRepository productRepository;

  @InjectMocks
  private UserService userService;

  @Test
  public void registerUser_shouldReturnSuccessMessageOnSuccessfulRegistration() {
    User userEntity = getUserEntity();
    UserDto userDto = getUserDto();
    userEntity.setUserId(null);
    when(userRepository.save(userEntity)).thenReturn(userEntity);
    String response = userService.registerUser(userDto);
    Assertions.assertEquals(REGISTER_USER_RESPONSE, response);
  }

  @Test
  public void basicAuthentication_shouldReturnIdWhenGivenValidEmailIdPassword() {
    User userEntity = getUserEntity();
    when(userRepository.findByEmail(EMAIL_ID)).thenReturn(userEntity);
    String response = userService.basicAuthentication(EMAIL_ID, PASSWORD);
    Assertions.assertEquals(USER_ID, response);
  }

  @Test
  public void basicAuthentication_shouldThrowExceptionWhenGivenInValidEmailIdPassword() {
    when(userRepository.findByEmail(EMAIL_ID)).thenReturn(null);
    String response = userService.basicAuthentication(EMAIL_ID, PASSWORD);
    Assertions.assertEquals(AUTHENTICATION_ERROR_RESPONSE, response);
  }

  @Test
  public void viewUser_shouldReturnUserDtoWhenGivenValidUserId() {
    User userEntity = getUserEntity();
    UserDto userDto = getUserDto();
    userDto.setPassword(null);
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.of(userEntity));
    UserDto response = userService.viewUser(USER_ID);
    Assertions.assertEquals(userDto, response);
  }

  @Test
  public void viewUser_shouldReturnNullWhenGivenInValidUserId() {
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.empty());
    UserDto response = userService.viewUser(USER_ID);
    Assertions.assertNull(response);
  }

  @Test
  public void viewUser_shouldReturnUserDtoWithProductListWhenGivenValidUserId() {
    User userEntity = getUserEntity();
    userEntity.setProducts(getProductList());
    UserDto userDto = getUserDto();
    userDto.setProducts(getProductDtoList());
    userDto.setPassword(null);
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.of(userEntity));
    UserDto response = userService.viewUser(USER_ID);
    Assertions.assertEquals(userDto, response);
  }

  @Test
  public void assignProduct_shouldReturnSuccessMessageWhenGivenValidUserId() {
    User userEntity = getUserEntity();
    User userEntityAfterSave = getUserEntity();
    userEntityAfterSave.setProducts(getProductList());
    UserDto userDto = getUserDto();
    userDto.setProducts(getProductDtoList());
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.of(userEntity));
    when(userRepository.save(userEntity)).thenReturn(userEntityAfterSave);
    String response = userService.assignProduct(USER_ID, getProductDto());
    Assertions.assertEquals(ASSIGN_PRODUCT_RESPONSE, response);
  }

  @Test
  public void assignProduct_shouldReturnNotFoundMessageWhenGivenInValidUserId() {
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.empty());
    String response = userService.assignProduct(USER_ID, getProductDto());
    Assertions.assertEquals(USER_NOT_FOUND_MESSAGE, response);
  }

  @Test
  public void updateProduct_shouldReturnSuccessMessageWhenGivenValidProductId() {
    Product product = getProduct();
    Product updatedProduct = getProduct();
    updatedProduct.setProductName("DataCable");
    ProductDto productDto = getProductDto();
    productDto.setProductName("DataCable");
    when(productRepository.findById(Long.parseLong(PRODUCT_ID))).thenReturn(Optional.of(product));
    when(productRepository.save(updatedProduct)).thenReturn(updatedProduct);
    String response = userService.updateProduct(productDto);
    Assertions.assertEquals(UPDATED_PRODUCT_RESPONSE, response);
  }

  @Test
  public void updateProduct_shouldReturnNotFoundMessageWhenGivenInValidProductId() {
    when(productRepository.findById(Long.parseLong(PRODUCT_ID))).thenReturn(Optional.empty());
    String response = userService.updateProduct(getProductDto());
    Assertions.assertEquals(PRODUCT_NOT_FOUND_MESSAGE, response);
  }

  @Test
  public void deleteProduct_shouldReturnSuccessMessageWhenGivenValidUserIdProductId() {
    User userEntity = getUserEntity();
    List<Product> productList = new ArrayList<>();
    productList.add(getProduct());
    userEntity.setProducts(productList);
    User userEntityAfterDelete = getUserEntity();
    userEntityAfterDelete.setProducts(Collections.emptyList());
    Product productEntity = getProduct();
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.of(userEntity));
    when(productRepository.findById(Long.parseLong(PRODUCT_ID))).thenReturn(Optional.of(productEntity));
    when(userRepository.save(userEntityAfterDelete)).thenReturn(userEntityAfterDelete);
    String response = userService.deleteProduct(USER_ID, PRODUCT_ID);
    verify(productRepository).deleteById(Long.parseLong(PRODUCT_ID));
    Assertions.assertEquals(DELETED_PRODUCT_RESPONSE, response);
  }

  @Test
  public void deleteProduct_shouldReturnNotFoundMessageWhenGivenInValidProductId() {
    when(productRepository.findById(Long.parseLong(PRODUCT_ID))).thenReturn(Optional.empty());
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.of(getUserEntity()));
    String response = userService.deleteProduct(USER_ID, PRODUCT_ID);
    Assertions.assertEquals(PRODUCT_NOT_FOUND_MESSAGE, response);
  }

  @Test
  public void deleteProduct_shouldReturnNotFoundMessageWhenGivenInValidUserId() {
    when(productRepository.findById(Long.parseLong(PRODUCT_ID))).thenReturn(Optional.of(getProduct()));
    when(userRepository.findById(Long.parseLong(USER_ID))).thenReturn(Optional.empty());
    String response = userService.deleteProduct(USER_ID, PRODUCT_ID);
    Assertions.assertEquals(USER_NOT_FOUND_MESSAGE, response);
  }

  private List<ProductDto> getProductDtoList() {
    return Collections.singletonList(getProductDto());
  }

  private ProductDto getProductDto() {
    return ProductDto.builder()
        .price(PRICE)
        .productId(Long.parseLong(PRODUCT_ID))
        .productName(PRODUCT_NAME)
        .productType(PRODUCT_TYPE)
        .build();
  }

  private Product getProduct() {
    return Product.builder()
        .price(PRICE)
        .productId(Long.parseLong(PRODUCT_ID))
        .productName(PRODUCT_NAME)
        .productType(PRODUCT_TYPE)
        .build();
  }

  private List<Product> getProductList() {
    return Collections.singletonList(Product.builder()
        .price(PRICE)
        .productId(Long.parseLong(PRODUCT_ID))
        .productName(PRODUCT_NAME)
        .productType(PRODUCT_TYPE)
        .build());
  }

  private UserDto getUserDto() {
    return UserDto.builder()
        .userId(Long.parseLong(USER_ID))
        .email(EMAIL_ID)
        .firstName(FIRST_NAME)
        .lastName(LAST_NAME)
        .password(PASSWORD)
        .products(Collections.emptyList())
        .build();
  }

  private User getUserEntity() {
    return User.builder()
        .userId(Long.parseLong(USER_ID))
        .email(EMAIL_ID)
        .firstName(FIRST_NAME)
        .lastName(LAST_NAME)
        .password(PASSWORD)
        .build();
  }
}
