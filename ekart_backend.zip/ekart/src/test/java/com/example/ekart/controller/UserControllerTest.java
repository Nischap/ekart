package com.example.ekart.controller;

import static com.example.ekart.util.Constants.ASSIGN_PRODUCT_RESPONSE;
import static com.example.ekart.util.Constants.DELETED_PRODUCT_RESPONSE;
import static com.example.ekart.util.Constants.EMAIL_ID;
import static com.example.ekart.util.Constants.PASSWORD;
import static com.example.ekart.util.Constants.PRODUCT_ID;
import static com.example.ekart.util.Constants.REGISTER_USER_RESPONSE;
import static com.example.ekart.util.Constants.UPDATED_PRODUCT_RESPONSE;
import static com.example.ekart.util.Constants.USER_ID;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.example.ekart.model.ProductDto;
import com.example.ekart.model.UserDto;
import com.example.ekart.service.UserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

  @InjectMocks
  private UserController userController;

  @Mock
  private UserService userService;

  @Test
  public void registerUserTest() {
    UserDto userDto = Mockito.mock(UserDto.class);
    when(userService.registerUser(userDto)).thenReturn(REGISTER_USER_RESPONSE);
    String response = userController.registerUser(userDto).getBody();
    Assertions.assertEquals(REGISTER_USER_RESPONSE, response);
  }

  @Test
  public void getBasicAuthenticationTest() {
    when(userService.basicAuthentication(EMAIL_ID, PASSWORD)).thenReturn(USER_ID);
    String response = userController.getBasicAuthentication(EMAIL_ID, PASSWORD).getBody();
    Assertions.assertEquals(USER_ID, response);
  }

  @Test
  public void getUserTest() {
    UserDto userDto = mock(UserDto.class);
    when(userService.viewUser(USER_ID)).thenReturn(userDto);
    UserDto response = userController.getUser(USER_ID).getBody();
    Assertions.assertEquals(userDto, response);
  }

  @Test
  public void addProductTest() {
    ProductDto productDto = mock(ProductDto.class);
    when(userService.assignProduct(USER_ID, productDto)).thenReturn(ASSIGN_PRODUCT_RESPONSE);
    String response = userController.addProduct(USER_ID, productDto).getBody();
    Assertions.assertEquals(ASSIGN_PRODUCT_RESPONSE, response);
  }

  @Test
  public void updateProductTest() {
    ProductDto productDto = mock(ProductDto.class);
    when(userService.updateProduct(productDto)).thenReturn(UPDATED_PRODUCT_RESPONSE);
    String response = userController.updateProduct(productDto).getBody();
    Assertions.assertEquals(UPDATED_PRODUCT_RESPONSE, response);
  }

  @Test
  public void deleteProductTest() {
    when(userService.deleteProduct(USER_ID, PRODUCT_ID)).thenReturn(DELETED_PRODUCT_RESPONSE);
    String response = userController.deleteProduct(USER_ID, PRODUCT_ID).getBody();
    Assertions.assertEquals(DELETED_PRODUCT_RESPONSE, response);
  }

}
