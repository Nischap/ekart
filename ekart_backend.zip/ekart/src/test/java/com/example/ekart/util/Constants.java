package com.example.ekart.util;

public class Constants {

  public static final String REGISTER_USER_RESPONSE = "User Registered Successfully";
  public static final String ASSIGN_PRODUCT_RESPONSE = "Product added successfully";
  public static final String UPDATED_PRODUCT_RESPONSE = "Product Updated successfully";
  public static final String DELETED_PRODUCT_RESPONSE = "Product deleted successfully";
  public static final String AUTHENTICATION_ERROR_RESPONSE = "Incorrect Username Or Password";
  public static final String USER_NOT_FOUND_MESSAGE = "User not found";
  public static final String PRODUCT_NOT_FOUND_MESSAGE = "Product not found";
  public static final String EMAIL_ID = "test@gmail.com";
  public static final String PASSWORD = "password";
  public static final String USER_ID = "12345";
  public static final String PRODUCT_ID = "123";
  public static final String FIRST_NAME = "firstName";
  public static final String LAST_NAME = "lastName";
  public static final String PRODUCT_NAME = "Cable";
  public static final String PRODUCT_TYPE = "Accessories";
  public static final Double PRICE = 120d;
}
