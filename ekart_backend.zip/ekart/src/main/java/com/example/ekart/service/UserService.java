package com.example.ekart.service;

import com.example.ekart.entity.Product;
import com.example.ekart.entity.User;
import com.example.ekart.model.ProductDto;
import com.example.ekart.model.ResetPasswordDto;
import com.example.ekart.model.UserDto;
import com.example.ekart.repository.ProductRepository;
import com.example.ekart.repository.UserRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

  @Autowired
  private UserRepository userRepository;

  @Autowired
  private ProductRepository productRepository;


  @Transactional
  public String registerUser(UserDto userDto) {
    User user = User.builder()
        .firstName(userDto.getFirstName())
        .lastName(userDto.getLastName())
        .email(userDto.getEmail().toLowerCase())
        .password(userDto.getPassword())
        .question(userDto.getQuestion())
        .answer(userDto.getAnswer().toLowerCase())
        .build();
    userRepository.save(user);
    return "User Registered Successfully";
  }

  public String basicAuthentication(String email, String password) {

    User optionalUser = userRepository.findByEmail(email.toLowerCase());

    if (optionalUser != null && password.equals(optionalUser.getPassword())) {
      return optionalUser.getUserId().toString();
    }
    return "Incorrect Username Or Password";
  }

  public UserDto viewUser(String userId) {
    Optional<User> optionalUser = userRepository.findById(Long.parseLong(userId));
    return optionalUser.map(user -> UserDto.builder()
            .userId(user.getUserId())
            .firstName(user.getFirstName())
            .lastName(user.getLastName())
            .email(user.getEmail())
            .products(getProductListDto(user.getProducts()))
            .build()).orElse(null);
  }

  private List<ProductDto> getProductListDto(List<Product> products) {
    List<ProductDto> productDtoList = new ArrayList<>();
    if(Objects.isNull(products))
      return productDtoList;
    for (Product product : products) {
      ProductDto productDto = ProductDto.builder()
          .productId(product.getProductId())
          .productName(product.getProductName())
          .productType(product.getProductType())
          .price(product.getPrice())
          .build();
      productDtoList.add(productDto);
    }
    return productDtoList;
  }

  @Transactional
  public String assignProduct(String userId, ProductDto productDto) {
    Optional<User> optionalUser = userRepository.findById(Long.parseLong(userId));
    if (!optionalUser.isPresent())
      return "User not found";
    List<Product> products = optionalUser.get().getProducts();
    products = Objects.isNull(products) ? new ArrayList<>() : products ;
    Product product = Product.builder()
            .price(productDto.getPrice())
            .productType(productDto.getProductType())
            .productName(productDto.getProductName())
            .build();
    products.add(product);
    User user = optionalUser.get();
    user.setProducts(products);
    userRepository.save(user);
    return "Product added successfully";

  }

  @Transactional
  public String updateProduct(ProductDto productDto) {
    Optional<Product> optionalProduct = productRepository.findById(productDto.getProductId());
    if (optionalProduct.isPresent()) {
      Product product = Product.builder()
          .productId(productDto.getProductId())
          .price(productDto.getPrice())
          .productType(productDto.getProductType())
          .productName(productDto.getProductName())
          .build();
      productRepository.save(product);
      return "Product Updated successfully";
    }
    return "Product not found";

  }

  @Transactional
  public String resetPassword(ResetPasswordDto resetPasswordDto) {
    User optionalUser = userRepository.findByEmail(resetPasswordDto.getEmail().toLowerCase());
   if(optionalUser != null && resetPasswordDto.getAnswer().equalsIgnoreCase(optionalUser.getAnswer())){
     optionalUser.setPassword(resetPasswordDto.getPassword());
     userRepository.save(optionalUser);
     return "Password Updated successfully";
   }
    return "Incorrect Details";
  }

  @Transactional
  public String deleteProduct(String userId, String productId) {
    Optional<Product> optionalProduct = productRepository.findById(Long.parseLong(productId));
    Optional<User> optionalUser = userRepository.findById(Long.parseLong(userId));
    if (optionalUser.isPresent()) {
      if (optionalProduct.isPresent()) {
        List<Product> products = optionalUser.get().getProducts();
        products.remove(optionalProduct.get());
        User user = optionalUser.get();
        user.setProducts(products);
        userRepository.save(user);
        productRepository.deleteById(optionalProduct.get().getProductId());
        return "Product deleted successfully";
      } else {
        return "Product not found";
      }
    }
    return "User not found";

  }


}
