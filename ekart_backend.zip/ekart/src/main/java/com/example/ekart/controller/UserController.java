package com.example.ekart.controller;

import com.example.ekart.model.ProductDto;
import com.example.ekart.model.ResetPasswordDto;
import com.example.ekart.model.UserDto;
import com.example.ekart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

  @Autowired
  private UserService userService;

  @PostMapping(value = "/registerUser", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> registerUser(@RequestBody UserDto userDto) {
    return new ResponseEntity<>(userService.registerUser(userDto), HttpStatus.CREATED);
  }

  @GetMapping(value = "/user/getAuthenticate/{email}/{password}")
  public ResponseEntity<String> getBasicAuthentication(@PathVariable String email, @PathVariable String password) {
    String message = userService.basicAuthentication(email, password);
    return new ResponseEntity<>(message, HttpStatus.OK);
  }

  @GetMapping(value = "/user/getUser/{userId}")
  public ResponseEntity<UserDto> getUser(@PathVariable String userId) {
    return new ResponseEntity<>(userService.viewUser(userId), HttpStatus.OK);
  }

  @PostMapping(value = "/user/addProduct/{userId}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> addProduct(@PathVariable String userId, @RequestBody ProductDto productDto) {
    return new ResponseEntity<>(userService.assignProduct(userId, productDto), HttpStatus.CREATED);
  }

  @PutMapping(value = "/user/updateProduct", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> updateProduct(@RequestBody ProductDto productDto) {
    return new ResponseEntity<>(userService.updateProduct(productDto), HttpStatus.OK);
  }

  @DeleteMapping(value = "/user/deleteProduct/{userId}/{productId}")
  public ResponseEntity<String> deleteProduct(@PathVariable String userId, @PathVariable String productId) {
    return new ResponseEntity<>(userService.deleteProduct(userId, productId), HttpStatus.OK);
  }

  @PutMapping(value = "/user/resetPassword", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordDto resetPasswordDto) {
    return new ResponseEntity<>(userService.resetPassword(resetPasswordDto), HttpStatus.CREATED);
  }

}